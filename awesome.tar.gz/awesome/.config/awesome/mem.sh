free | grep Mem | awk '{print "Mem use: "  $3 / $2 * 100 "%"  }'
